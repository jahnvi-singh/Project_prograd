# ToDo Today
## A To Do app built with Bootstrap and JavaScript.

Add items by completing the input field and clicking the "Add Item" button or hitting the ENTER key. 
Red Button is for deletion and green button for marking the task as complete.

